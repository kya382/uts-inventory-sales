
<?php

use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    public function up(): void
    {
        // Tabel products sudah tersedia di database.
    }

    public function down(): void
    {
        // Tabel products tidak dihapus oleh migrasi ini.
    }
};
