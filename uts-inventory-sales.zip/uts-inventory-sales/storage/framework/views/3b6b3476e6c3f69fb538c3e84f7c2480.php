<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi Pembelian - Berkah Elektronik</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f6fa;
            margin: 0;
            padding: 30px;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 8px #ddd;
            overflow-x: auto;
        }

        h2 {
            margin-top: 0;
        }

        .btn {
            display: inline-block;
            padding: 10px 15px;
            background: #dc2626;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .btn:hover {
            background: #b91c1c;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            text-align: left;
            white-space: nowrap;
        }

        th {
            background: #dc2626;
            color: white;
        }

        .detail-btn {
            display: inline-block;
            background: #dc2626;
            color: white;
            padding: 8px 12px;
            text-decoration: none;
            border-radius: 4px;
        }

        .detail-btn:hover {
            background: #b91c1c;
        }

        .empty {
            text-align: center;
            color: #777;
            padding: 25px;
        }

        .success {
            background: #dcfce7;
            color: #166534;
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 15px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Transaksi Pembelian</h2>
        <p>Kelola dan lihat data pembelian barang dari supplier.</p>

        <a href="<?php echo e(url('/dashboard')); ?>"
           class="btn"
           style="background:#555;">
            ← Kembali ke Dashboard
        </a>

        <a href="<?php echo e(route('purchases.create')); ?>" class="btn">
            + Tambah Pembelian
        </a>

        <?php if(session('success')): ?>
            <div class="success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="success" style="background:#fee2e2;color:#991b1b;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>No.</th>
                    <th>No. Pembelian</th>
                    <th>Supplier</th>
                    <th>Tanggal</th>
                    <th>Total Pembelian</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>

                        <td><?php echo e($purchase->purchase_number); ?></td>

                        <td><?php echo e($purchase->supplier->name ?? '-'); ?></td>

                        <td>
                            <?php echo e($purchase->purchase_date->format('d-m-Y')); ?>

                        </td>

                        <td>
                            Rp <?php echo e(number_format((float) $purchase->total_amount, 0, ',', '.')); ?>

                        </td>

                        <td><?php echo e(ucfirst($purchase->status)); ?></td>

                        <td>
                            <a href="<?php echo e(route('purchases.show', $purchase->id)); ?>"
                               class="detail-btn">
                                Detail
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="empty">
                            Belum ada transaksi pembelian.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html><?php /**PATH C:\xamppp\htdocs\uts-inventory-sales\resources\views/purchases/index.blade.php ENDPATH**/ ?>