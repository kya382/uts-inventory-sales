
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Penjualan</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            color: #333;
        }

        .header {
            background: #b91c1c;
            color: white;
            padding: 22px 30px;
        }

        .header h2 {
            margin: 0 0 6px;
        }

        .container {
            padding: 25px;
        }

        .back {
            display: inline-block;
            margin-bottom: 20px;
            color: #b91c1c;
            text-decoration: none;
            font-weight: bold;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 18px;
            margin-bottom: 25px;
        }

        .card {
            background: white;
            padding: 22px;
            border-radius: 10px;
            box-shadow: 0 2px 8px #00000010;
        }

        .card p {
            margin: 0 0 12px;
            color: #666;
        }

        .card h2 {
            margin: 0;
            color: #b91c1c;
        }

        .panel {
            background: white;
            padding: 22px;
            border-radius: 10px;
            margin-bottom: 25px;
            box-shadow: 0 2px 8px #00000010;
            overflow-x: auto;
        }

        .filter {
            display: flex;
            flex-wrap: wrap;
            align-items: end;
            gap: 12px;
        }

        .filter label {
            display: block;
            margin-bottom: 7px;
            font-size: 14px;
        }

        input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 6px;
        }

        button, .reset {
            display: inline-block;
            padding: 10px 16px;
            border: none;
            border-radius: 6px;
            background: #b91c1c;
            color: white;
            cursor: pointer;
            text-decoration: none;
        }

        .reset {
            background: #666;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 650px;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }

        th {
            background: #fff1f1;
            color: #991b1b;
        }

        .empty {
            text-align: center;
            color: #777;
            padding: 25px;
        }

        

.pagination {
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid #ddd;
}

.pagination nav {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
}

.pagination nav > div:first-child {
    font-size: 16px;
}

.pagination nav > div:last-child {
    display: flex;
    align-items: center;
    gap: 8px;
}

.pagination nav a,
.pagination nav span {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    min-width: 40px;
    min-height: 40px;
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 7px;
    background: white;
    color: #991b1b;
    text-decoration: none;
    font-size: 16px;
}

.pagination nav span[aria-current="page"] span {
    background: #991b1b;
    color: white;
}

.pagination svg {
    width: 16px !important;
    height: 16px !important;
}



        @media (max-width: 600px) {
            .container {
                padding: 14px;
            }

            .header {
                padding: 18px;
            }
        }
    </style>
</head>
<body>

<div class="header">
    <h2>Laporan Penjualan</h2>
    <p>Ringkasan transaksi dan barang yang terjual</p>
</div>

<div class="container">

    <a href="<?php echo e(route('dashboard')); ?>" class="back">
        ← Kembali ke Dashboard
    </a>

    <div class="panel">
        <h3>Filter Tanggal</h3>

        <form action="<?php echo e(route('reports.sales')); ?>" method="GET" class="filter">
            <div>
                <label for="tanggal_awal">Dari tanggal</label>
                <input
                    type="date"
                    id="tanggal_awal"
                    name="tanggal_awal"
                    value="<?php echo e($tanggalAwal); ?>"
                >
            </div>

            <div>
                <label for="tanggal_akhir">Sampai tanggal</label>
                <input
                    type="date"
                    id="tanggal_akhir"
                    name="tanggal_akhir"
                    value="<?php echo e($tanggalAkhir); ?>"
                >
            </div>

            <button type="submit">Tampilkan</button>
            <a href="<?php echo e(route('reports.sales')); ?>" class="reset">Reset</a>
        </form>
    </div>

    <div class="cards">
        <div class="card">
            <p>Total Transaksi</p>
            <h2><?php echo e(number_format($totalTransaksi, 0, ',', '.')); ?></h2>
        </div>

        <div class="card">
            <p>Total Omzet</p>
            <h2>Rp <?php echo e(number_format($totalOmzet, 0, ',', '.')); ?></h2>
        </div>
    </div>

    <div class="panel">
        <h3>Riwayat Penjualan</h3>

        <table>
            <thead>
                <tr>
                    <th>No.</th>
                    <th>No. Transaksi</th>
                    <th>Tanggal</th>
                    <th>Jumlah Jenis Barang</th>
                    <th>Total Penjualan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($penjualan->firstItem() + $loop->index); ?></td>
                        <td><?php echo e($sale->sale_number); ?></td>
                        <td>
                            <?php echo e($sale->sold_at ? $sale->sold_at->format('d-m-Y H:i') : '-'); ?>

                        </td>
                        <td><?php echo e($sale->items->count()); ?></td>
                        <td>Rp <?php echo e(number_format($sale->total_amount, 0, ',', '.')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="empty">
                            Belum ada transaksi penjualan.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="pagination">
            <?php echo e($penjualan->links()); ?>

        </div>
    </div>

    <div class="panel">
        <h3>Rincian Barang Terjual</h3>

        <table>
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Nama Barang</th>
                    <th>Jumlah Terjual</th>
                    <th>Total Penjualan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $barangTerjual; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($barang->nama_barang); ?></td>
                        <td><?php echo e($barang->jumlah_terjual); ?></td>
                        <td>Rp <?php echo e(number_format($barang->total_penjualan, 0, ',', '.')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="empty">
                            Belum ada barang yang terjual.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>
</body>
</html>
<?php /**PATH C:\xamppp\htdocs\uts-inventory-sales\resources\views/reports/sales.blade.php ENDPATH**/ ?>