
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Supplier</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            margin: 30px;
        }

        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 8px;
        }

        label {
            display: block;
            margin-top: 15px;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button, .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }

        button {
            background: #dc2626;
            color: white;
        }

        .btn {
            background: #ddd;
            color: #333;
        }

        .error {
            color: #b91c1c;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Edit Supplier</h2>

    <?php if($errors->any()): ?>
        <div class="error">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('suppliers.update', $supplier->id)); ?>"
          method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label>Nama Supplier *</label>
        <input type="text" name="name"
               value="<?php echo e(old('name', $supplier->name)); ?>" required>

        <label>Nomor Telepon</label>
        <input type="text" name="phone"
               value="<?php echo e(old('phone', $supplier->phone)); ?>">

        <label>Email</label>
        <input type="email" name="email"
               value="<?php echo e(old('email', $supplier->email)); ?>">

        <label>Alamat</label>
        <textarea name="address" rows="3"><?php echo e(old('address', $supplier->address)); ?></textarea>

        <button type="submit">Simpan Perubahan</button>
        <a href="<?php echo e(route('suppliers.index')); ?>" class="btn">Kembali</a>
    </form>
</div>
</body>
</html>
<?php /**PATH C:\xamppp\htdocs\uts-inventory-sales\resources\views/suppliers/edit.blade.php ENDPATH**/ ?>