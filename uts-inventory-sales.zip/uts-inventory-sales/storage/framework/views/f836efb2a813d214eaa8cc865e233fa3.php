<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Supplier | BERKAH ELEKTRONIK</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 30px;
            background: #f5f6fa;
            color: #292929;
        }

        .container {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 12px #0000000d;
            overflow-x: auto;
        }

        h2 {
            color: #991b1b;
            margin-top: 0;
            margin-bottom: 20px;
        }

        .btn {
            display: inline-block;
            padding: 10px 15px;
            background: #dc2626;
            color: white;
            text-decoration: none;
            border: none;
            border-radius: 5px;
            margin-bottom: 15px;
            cursor: pointer;
            font-size: 14px;
        }

        .btn:hover {
            background: #991b1b;
        }

        .btn-kembali {
            background: #64748b;
            margin-right: 5px;
        }

        .btn-kembali:hover {
            background: #475569;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            min-width: 700px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background: #991b1b;
            color: white;
        }

        tbody tr:hover {
            background: #fff7f7;
        }

        .edit {
            display: inline-block;
            background: #991b1b;
            color: white;
            padding: 7px 10px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 13px;
        }

        .edit:hover {
            background: #7f1d1d;
        }

        .hapus {
            background: #dc2626;
            color: white;
            padding: 7px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
        }

        .hapus:hover {
            background: #991b1b;
        }

        .success {
            background: #dcfce7;
            color: #166534;
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 5px;
        }

        .error {
            background: #fee2e2;
            color: #991b1b;
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 5px;
        }

        .pagination {
            margin-top: 20px;
        }

        @media (max-width: 600px) {
            body {
                padding: 12px;
            }

            .container {
                padding: 16px;
            }
        }
    </style>
</head>

<body>
<div class="container">

    <h2>🚚 Data Supplier</h2>

    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-kembali">
        ← Kembali ke Dashboard
    </a>

    <a href="<?php echo e(route('suppliers.create')); ?>" class="btn">
        + Tambah Supplier
    </a>

    <?php if(session('success')): ?>
        <div class="success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="error">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div><?php echo e($error); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama Supplier</th>
                <th>Telepon</th>
                <th>Email</th>
                <th>Alamat</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($suppliers->firstItem() + $loop->index); ?></td>
                    <td><?php echo e($supplier->name); ?></td>
                    <td><?php echo e($supplier->phone ?? '-'); ?></td>
                    <td><?php echo e($supplier->email ?? '-'); ?></td>
                    <td><?php echo e($supplier->address ?? '-'); ?></td>
                    <td>
                        <a href="<?php echo e(route('suppliers.edit', $supplier->id)); ?>"
                           class="edit">Edit</a>

                        <form
                            action="<?php echo e(route('suppliers.destroy', $supplier->id)); ?>"
                            method="POST"
                            style="display:inline"
                            onsubmit="return confirm('Yakin ingin menghapus supplier ini?')">

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button type="submit" class="hapus">
                                Hapus
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" style="text-align:center;">
                        Belum ada data supplier.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="pagination">
        <?php echo e($suppliers->links()); ?>

    </div>

</div>
</body>
</html><?php /**PATH C:\xamppp\htdocs\uts-inventory-sales\resources\views/suppliers/index.blade.php ENDPATH**/ ?>