
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pengguna - Inventory</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 25px;
            color: #333;
        }

        .container {
            max-width: 1100px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 8px #ddd;
        }

        h2 {
            color: #c62828;
            margin-top: 0;
        }

        .btn {
            display: inline-block;
            padding: 9px 12px;
            background: #c62828;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            font-size: 13px;
            margin: 2px;
        }

        .btn:hover {
            background: #a61f1f;
        }

        .btn-back {
            background: #555;
        }

        .btn-edit {
            background: #e69500;
        }

        .btn-delete {
            background: #333;
        }

        .table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            background: white;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background: #c62828;
            color: white;
        }

        tr:nth-child(even) {
            background: #fff5f5;
        }

        .role {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 5px;
            font-size: 12px;
            font-weight: bold;
        }

        .admin {
            background: #c62828;
            color: white;
        }

        .staff {
            background: #ffe0e0;
            color: #a61f1f;
        }

        .success {
            background: #fff0f0;
            color: #a61f1f;
            border: 1px solid #f3b5b5;
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .error {
            background: #ffe0e0;
            color: #a61f1f;
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .pagination {
            margin-top: 20px;
        }

        form {
            display: inline;
        }

        @media (max-width: 600px) {
            body {
                padding: 10px;
            }

            .container {
                padding: 15px;
            }
        }
    </style>
</head>

<body>
<div class="container">
    <h2>Data Pengguna</h2>
    <p>Kelola akun Admin dan Staff pada sistem inventaris.</p>

    <?php if(session('success')): ?>
        <div class="success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="error">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('users.create')); ?>" class="btn">
        + Tambah Pengguna
    </a>

    <a href="<?php echo e(url('/dashboard')); ?>" class="btn btn-back">
        Kembali ke Dashboard
    </a>

    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Nama</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($users->firstItem() + $loop->index); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->username); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                            <span class="role <?php echo e($user->role === 'admin' ? 'admin' : 'staff'); ?>">
                                <?php echo e(strtoupper($user->role)); ?>

                            </span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('users.edit', $user->id)); ?>"
                               class="btn btn-edit">
                                Edit
                            </a>

                            <?php if($user->id !== auth()->id()): ?>
                                <form action="<?php echo e(route('users.destroy', $user->id)); ?>"
                                      method="POST"
                                      onsubmit="return confirm('Yakin ingin menghapus akun ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit" class="btn btn-delete">
                                        Hapus
                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" style="text-align: center;">
                            Belum ada data pengguna.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="pagination">
        <?php echo e($users->links()); ?>

    </div>
</div>
</body>
</html>
<?php /**PATH C:\xamppp\htdocs\uts-inventory-sales\resources\views/users/index.blade.php ENDPATH**/ ?>