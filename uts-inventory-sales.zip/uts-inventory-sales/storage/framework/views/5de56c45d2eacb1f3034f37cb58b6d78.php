
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pengguna - Inventory</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 30px;
        }

        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            border-top: 5px solid #c62828;
        }

        h2 {
            color: #c62828;
            margin-top: 0;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 11px;
            margin-top: 7px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button, .back {
            display: inline-block;
            margin-top: 20px;
            padding: 11px 16px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
        }

        button {
            background: #c62828;
            color: white;
        }

        .back {
            background: #666;
            color: white;
        }

        .error {
            color: #c62828;
            font-size: 13px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit Akun Pengguna</h2>

    <?php if($errors->any()): ?>
        <div class="error">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label>Nama Lengkap</label>
        <input type="text" name="name"
            value="<?php echo e(old('name', $user->name)); ?>" required>

        <label>Username</label>
        <input type="text" name="username"
            value="<?php echo e(old('username', $user->username)); ?>" required>

        <label>Email</label>
        <input type="email" name="email"
            value="<?php echo e(old('email', $user->email)); ?>" required>

        <label>Password Baru</label>
        <input type="password" name="password"
            placeholder="Kosongkan jika tidak ingin mengganti password">

        <label>Role</label>
        <select name="role" required>
            <option value="admin"
                <?php echo e(old('role', $user->role) === 'admin' ? 'selected' : ''); ?>>
                Admin
            </option>
            <option value="staff"
                <?php echo e(old('role', $user->role) === 'staff' ? 'selected' : ''); ?>>
                Staff
            </option>
        </select>

        <button type="submit">Simpan Perubahan</button>
        <a href="<?php echo e(route('users.index')); ?>" class="back">Kembali</a>
    </form>
</div>

</body>
</html>
<?php /**PATH C:\xamppp\htdocs\uts-inventory-sales\resources\views/users/edit.blade.php ENDPATH**/ ?>