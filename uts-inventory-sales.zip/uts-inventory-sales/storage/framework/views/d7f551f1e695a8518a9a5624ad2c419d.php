
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | BERKAH ELEKTRONIK</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f5f6fa;
            color: #292929;
        }

        .sidebar {
            width: 250px;
            height: 100vh;
            background: #991b1b;
            color: white;
            position: fixed;
            top: 0;
            left: 0;
            padding: 25px 16px;
            display: flex;
            flex-direction: column;
            overflow-y: auto;
        }

        .brand {
            font-size: 19px;
            font-weight: bold;
            line-height: 1.5;
            padding: 0 10px 30px;
            border-bottom: 1px solid #c65a5a;
        }

        .brand small {
            display: block;
            font-size: 12px;
            font-weight: normal;
            color: #fee2e2;
        }

        .menu-title {
            font-size: 11px;
            color: #fecaca;
            margin: 25px 10px 10px;
            letter-spacing: 1px;
        }

        .menu {
            display: block;
            color: #fff;
            text-decoration: none;
            padding: 13px 12px;
            margin: 4px 0;
            border-radius: 8px;
            font-size: 14px;
            transition: 0.2s;
        }

        .menu:hover,
        .menu.active {
            background: #dc2626;
        }

        .logout {
            margin-top: auto;
            padding-top: 20px;
        }

        .logout button {
            width: 100%;
            padding: 12px;
            border: 1px solid #fecaca;
            border-radius: 8px;
            background: transparent;
            color: white;
            cursor: pointer;
            font-size: 14px;
        }

        .logout button:hover {
            background: #7f1d1d;
        }

        .main {
            margin-left: 250px;
            padding: 30px;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px;
        }

        .topbar h1 {
            font-size: 26px;
            margin-bottom: 8px;
        }

        .subtitle {
            color: #777;
            font-size: 14px;
        }

        .admin {
            background: white;
            border: 1px solid #eee;
            border-radius: 10px;
            padding: 12px 18px;
            font-size: 14px;
        }

        .welcome {
            background: white;
            border-radius: 12px;
            padding: 22px;
            margin-bottom: 25px;
            border-left: 5px solid #dc2626;
            box-shadow: 0 3px 12px #00000008;
        }

        .welcome h2 {
            font-size: 19px;
            margin-bottom: 8px;
        }

        .welcome p {
            font-size: 14px;
            color: #777;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: white;
            padding: 22px;
            border-radius: 12px;
            border: 1px solid #eee;
            box-shadow: 0 3px 12px #00000008;
        }

        .stat-label {
            color: #777;
            font-size: 13px;
            margin-bottom: 14px;
        }

        .stat-number {
            font-size: 29px;
            font-weight: bold;
            margin-bottom: 12px;
        }

        .stat-link {
            color: #dc2626;
            font-size: 12px;
            text-decoration: none;
        }

        .stat-link:hover {
            text-decoration: underline;
        }

        .icon {
            width: 38px;
            height: 38px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 10px;
            background: #fee2e2;
            color: #b91c1c;
            font-size: 20px;
            margin-bottom: 15px;
        }

        .content-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .panel {
            background: white;
            border: 1px solid #eee;
            border-radius: 12px;
            padding: 22px;
            box-shadow: 0 3px 12px #00000008;
        }

        .panel h3 {
            font-size: 17px;
            margin-bottom: 18px;
        }

        .quick-link {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid #eee;
            text-decoration: none;
            color: #333;
            font-size: 14px;
        }

        .quick-link:last-child {
            border-bottom: none;
        }

        .quick-link span:last-child {
            color: #dc2626;
            font-size: 20px;
        }

        .quick-link:hover {
            color: #dc2626;
        }

        .note {
            margin-top: 22px;
            color: #888;
            font-size: 12px;
            text-align: center;
        }

        @media (max-width: 1100px) {
            .stats {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .content-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 650px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .main {
                margin-left: 0;
                padding: 18px;
            }

            .topbar {
                align-items: flex-start;
                flex-direction: column;
            }

            .topbar h1 {
                font-size: 23px;
            }

            .stats {
                grid-template-columns: 1fr;
            }
        }
       </style>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<aside class="sidebar">
    <div class="brand">
        📦 BERKAH ELEKTRONIK
        <small>Management System</small>
    </div>

    <div class="menu-title">MENU UTAMA</div>

    <a href="<?php echo e(url('/dashboard')); ?>" class="menu active">
        🏠 &nbsp; Dashboard
    </a>

    <a href="<?php echo e(url('/products')); ?>" class="menu">
        📦 &nbsp; Kelola Barang
    </a>

    <a href="<?php echo e(url('/categories')); ?>" class="menu">
        🗂️ &nbsp; Kelola Kategori
    </a>

    <a href="<?php echo e(route('suppliers.index')); ?>" class="menu">
        🚚 &nbsp; Kelola Supplier
    </a>

    <?php if(auth()->user()->role === 'admin'): ?>
        <a href="<?php echo e(route('users.index')); ?>" class="menu">
            👥 &nbsp; Data Pengguna
        </a>
    <?php endif; ?>

    <div class="menu-title">TRANSAKSI</div>

    <a href="<?php echo e(route('purchases.index')); ?>" class="menu">
        🛒 &nbsp; Pembelian
    </a>

    <a href="<?php echo e(route('sales.index')); ?>" class="menu">
        💳 &nbsp; Penjualan
    </a>

    <a href="<?php echo e(route('reports.sales')); ?>" class="menu">
    📊 &nbsp; Laporan Penjualan
    </a>

    <div class="logout">
        <form action="<?php echo e(url('/logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit">↪ &nbsp; Keluar / Logout</button>
        </form>
    </div>
</aside>

<main class="main">

    <header class="topbar">
        <div>
            <h1>Dashboard</h1>
            <p class="subtitle">
                Ringkasan data inventori dan pengelolaan barang.
            </p>
        </div>

        <div class="admin">
            👤 &nbsp; <?php echo e(auth()->user()->name); ?>

            <strong>(<?php echo e(strtoupper(auth()->user()->role)); ?>)</strong>
        </div>
    </header>

    <section class="welcome">
        <h2>Selamat Datang di BERKAH ELEKTRONIK! 👋</h2>
        <p>
            Pantau barang, stok, kategori, dan supplier melalui satu halaman.
        </p>
    </section>

    <section class="stats">

        <div class="stat-card">
            <div class="icon">📦</div>
            <div class="stat-label">Total Barang</div>
            <div class="stat-number"><?php echo e($totalBarang); ?></div>
            <a href="<?php echo e(url('/products')); ?>" class="stat-link">Lihat data barang →</a>
        </div>

        <div class="stat-card">
            <div class="icon">📊</div>
            <div class="stat-label">Total Stok</div>
            <div class="stat-number"><?php echo e(number_format($totalStok, 0, ',', '.')); ?></div>
            <a href="<?php echo e(url('/products')); ?>" class="stat-link">Lihat stok barang →</a>
        </div>

        <div class="stat-card">
            <div class="icon">⚠️</div>
            <div class="stat-label">Stok Menipis</div>
            <div class="stat-number"><?php echo e($stokMenipis); ?></div>
            <a href="<?php echo e(url('/products')); ?>" class="stat-link">Periksa barang →</a>
        </div>

        <div class="stat-card">
            <div class="icon">🚚</div>
            <div class="stat-label">Total Supplier</div>
            <div class="stat-number"><?php echo e($totalSupplier ?? 0); ?></div>
            <a href="<?php echo e(route('suppliers.index')); ?>" class="stat-link">Lihat supplier →</a>
        </div>

    </section>
    </section>

<section class="panel" style="margin-bottom: 25px;">
    <h3>📊 Grafik Penjualan 7 Hari Terakhir</h3>
    <canvas id="grafikPenjualan" height="100"></canvas>
</section>

<section class="content-grid">

    <section class="content-grid">

        <div class="panel">
            <h3>⚡ Akses Cepat</h3>

            <a href="<?php echo e(url('/products')); ?>" class="quick-link">
                <span>Kelola Data Barang</span><span>→</span>
            </a>

            <a href="<?php echo e(url('/categories')); ?>" class="quick-link">
                <span>Kelola Kategori</span><span>→</span>
            </a>

            <a href="<?php echo e(route('suppliers.index')); ?>" class="quick-link">
                <span>Kelola Supplier</span><span>→</span>
            </a>

            <a href="<?php echo e(url('/products')); ?>" class="quick-link">
                <span>Periksa Stok Barang</span><span>→</span>
            </a>

            <?php if(auth()->user()->role === 'admin'): ?>
                <a href="<?php echo e(route('users.index')); ?>" class="quick-link">
                    <span>Kelola Akun Admin dan Staff</span><span>→</span>
                </a>
            <?php endif; ?>
        </div>

        <div class="panel">
            <h3>📋 Informasi Sistem</h3>

            <a href="<?php echo e(url('/products')); ?>" class="quick-link">
                <span>Data barang terdaftar</span><span><?php echo e($totalBarang); ?></span>
            </a>

            <a href="<?php echo e(url('/categories')); ?>" class="quick-link">
                <span>Pengelolaan kategori</span><span>→</span>
            </a>

            <a href="<?php echo e(route('suppliers.index')); ?>" class="quick-link">
                <span>Data supplier terdaftar</span><span><?php echo e($totalSupplier ?? 0); ?></span>
            </a>

            <a href="<?php echo e(url('/products')); ?>" class="quick-link">
                <span>Barang perlu diperiksa</span><span><?php echo e($stokMenipis); ?></span>
            </a>
        </div>

    </section>

    <p class="note">BERKAH ELEKTRONIK Management System</p>

</main>
<script>
    const areaGrafik = document.getElementById('grafikPenjualan');

    if (areaGrafik) {
        new Chart(areaGrafik, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($labelGrafik ?? [], 15, 512) ?>,
                datasets: [{
                    label: 'Total Penjualan (Rp)',
                    data: <?php echo json_encode($nilaiGrafik ?? [], 15, 512) ?>,
                    backgroundColor: '#dc2626',
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + Number(value).toLocaleString('id-ID');
                            }
                        }
                    }
                }
            }
        });
    }
</script>
</body>
</html>
<?php /**PATH C:\xamppp\htdocs\uts-inventory-sales\resources\views/dashboard.blade.php ENDPATH**/ ?>