
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pembelian</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f6fa;
            margin: 0;
            padding: 30px;
            color: #333;
        }

        .container {
            max-width: 700px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 8px #ddd;
        }

        h2 {
            margin-top: 0;
            color: #dc2626;
        }

        label {
            display: block;
            margin-top: 15px;
            margin-bottom: 7px;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            background: #dc2626;
            color: white;
            text-decoration: none;
            cursor: pointer;
        }

        .btn:hover {
            background: #b91c1c;
        }

        .back {
            background: #666;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Tambah Transaksi Pembelian</h2>
        <p>Isi data pembelian barang dari supplier.</p>

        <form action="<?php echo e(route('purchases.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <label>Supplier</label>
            <select name="supplier_id" required>
                <option value="">-- Pilih Supplier --</option>
                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($supplier->id); ?>">
                        <?php echo e($supplier->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <label>Tanggal Pembelian</label>
            <input type="date" name="purchase_date"
                   value="<?php echo e(date('Y-m-d')); ?>" required>

            <label>Produk</label>
            <select name="product_id" required>
                <option value="">-- Pilih Produk --</option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->id); ?>">
                        <?php echo e($product->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <label>Jumlah Barang</label>
            <input type="number" name="quantity" min="1"
                   placeholder="Masukkan jumlah barang" required>

            <label>Harga Beli per Barang (Rp)</label>
            <input type="text" name="price" id="price"
       placeholder="Contoh: 10.000" required
       inputmode="numeric"
       oninput="this.value = this.value.replace(/[^0-9]/g, '')">

            <button type="submit" class="btn">Simpan Pembelian</button>

            <a href="<?php echo e(route('purchases.index')); ?>" class="btn back">
                Kembali
            </a>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\xamppp\htdocs\uts-inventory-sales\resources\views/purchases/create.blade.php ENDPATH**/ ?>