<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pembelian - Berkah Elektronik</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f6fa;
            margin: 0;
            padding: 30px;
            color: #333;
        }

        .container {
            max-width: 1000px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 8px #ddd;
            overflow-x: auto;
        }

        h2 {
            color: #991b1b;
            margin-top: 0;
        }

        .btn {
            display: inline-block;
            padding: 10px 15px;
            background: #dc2626;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .btn:hover {
            background: #991b1b;
        }

        .info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }

        .info-card {
            background: #fff5f5;
            border: 1px solid #fecaca;
            border-radius: 8px;
            padding: 15px;
        }

        .label {
            color: #666;
            font-size: 13px;
            margin-bottom: 8px;
        }

        .value {
            font-weight: bold;
            overflow-wrap: anywhere;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }

        th {
            background: #dc2626;
            color: white;
        }

        .total {
            text-align: right;
            font-size: 20px;
            font-weight: bold;
            color: #991b1b;
            margin-top: 25px;
        }

        .empty {
            text-align: center;
            padding: 20px;
            color: #777;
        }

        @media (max-width: 600px) {
            body {
                padding: 12px;
            }

            .container {
                padding: 15px;
            }
        }
    </style>
</head>

<body>
<div class="container">

    <h2>Detail Pembelian</h2>
    <p>Informasi lengkap transaksi pembelian Berkah Elektronik.</p>

    <a href="<?php echo e(route('purchases.index')); ?>" class="btn">
        ← Kembali ke Pembelian
    </a>

    <div class="info">
        <div class="info-card">
            <div class="label">Nomor Pembelian</div>
            <div class="value"><?php echo e($purchase->purchase_number); ?></div>
        </div>

        <div class="info-card">
            <div class="label">Supplier</div>
            <div class="value"><?php echo e($purchase->supplier->name ?? '-'); ?></div>
        </div>

        <div class="info-card">
            <div class="label">Tanggal Pembelian</div>
            <div class="value">
                <?php echo e(\Carbon\Carbon::parse($purchase->purchase_date)->format('d-m-Y')); ?>

            </div>
        </div>

        <div class="info-card">
            <div class="label">Status</div>
            <div class="value"><?php echo e(ucfirst($purchase->status)); ?></div>
        </div>
    </div>

    <h3>Daftar Barang yang Dibeli</h3>

    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama Barang</th>
                <th>Jumlah</th>
                <th>Harga Satuan</th>
                <th>Subtotal</th>
            </tr>
        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $purchase->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($detail->product->name ?? 'Barang tidak ditemukan'); ?></td>
                    <td><?php echo e($detail->quantity); ?></td>
                    <td>
                        Rp <?php echo e(number_format((float) $detail->price, 0, ',', '.')); ?>

                    </td>
                    <td>
                        Rp <?php echo e(number_format((float) $detail->subtotal, 0, ',', '.')); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="empty">
                        Belum ada detail barang untuk transaksi ini.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="total">
        Total Pembelian:
        Rp <?php echo e(number_format((float) $purchase->total_amount, 0, ',', '.')); ?>

    </div>

</div>
</body>
</html><?php /**PATH C:\xamppp\htdocs\uts-inventory-sales\resources\views/purchases/show.blade.php ENDPATH**/ ?>