
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Penjualan - Berkah Elektronik</title>

    <style>
        * { box-sizing: border-box; }

        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 25px;
            color: #333;
        }

        .container {
            max-width: 850px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px #ddd;
        }

        h2 { color: #991b1b; margin-top: 0; }

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 11px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 15px;
        }

        .field { min-width: 0; }

        .item-row {
            display: grid;
            grid-template-columns: 2fr 1fr auto;
            gap: 12px;
            align-items: end;
            padding: 15px;
            margin: 12px 0;
            border: 1px solid #eee;
            border-radius: 8px;
            background: #fffafa;
        }

        .item-row label { margin-top: 0; }

        .stock-info {
            display: block;
            margin-top: 6px;
            font-size: 12px;
            color: #666;
        }

        button, .back-link {
            display: inline-block;
            padding: 11px 16px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
        }

        .add-button {
            color: #991b1b;
            background: white;
            border: 1px solid #991b1b;
            margin: 8px 0 20px;
        }

        .remove-button {
            background: #fee2e2;
            color: #991b1b;
        }

        .save-button {
            background: #991b1b;
            color: white;
        }

        .back-link {
            background: #777;
            color: white;
            margin-left: 5px;
        }

        .total-box {
            padding: 18px;
            margin: 10px 0 20px;
            background: #fff1f2;
            color: #991b1b;
            border-radius: 8px;
        }

        .total-number {
            font-size: 25px;
            font-weight: bold;
            margin-top: 5px;
        }

        .errors {
            padding: 12px 25px;
            background: #fee2e2;
            color: #991b1b;
            border-radius: 5px;
            margin-bottom: 18px;
        }

        @media (max-width: 600px) {
            body { padding: 12px; }
            .item-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Tambah Penjualan</h2>
    <p>Tambahkan beberapa jenis barang dalam satu transaksi.</p>

    <?php if($errors->any()): ?>
        <div class="errors">
            <strong>Periksa kembali data berikut:</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('sales.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div style="margin-bottom: 22px;">
            <label for="sold_at">Tanggal Penjualan</label>
            <input
                type="datetime-local"
                id="sold_at"
                name="sold_at"
                value="<?php echo e(old('sold_at', now()->format('Y-m-d\TH:i'))); ?>"
                required
            >
        </div>

        <label>Daftar Barang</label>
        <div id="itemsContainer"></div>

        <button type="button" class="add-button" id="addItem">
            + Tambah Barang
        </button>

        <div class="total-box">
            <div>Perkiraan Total Transaksi</div>
            <div class="total-number" id="totalDisplay">Rp 0</div>
        </div>

        <button type="submit" class="save-button">
            Simpan Penjualan
        </button>

        <a href="<?php echo e(route('sales.index')); ?>" class="back-link">
            Kembali
        </a>
    </form>
</div>

<script>
    const products = <?php echo e(Illuminate\Support\Js::from(
        $products->map(fn ($product) => [
            'id' => $product->id,
            'name' => $product->name,
            'price' => (float) $product->price,
            'stock' => (int) $product->stock,
        ])->values()
    )); ?>;

    const container = document.getElementById('itemsContainer');
    const totalDisplay = document.getElementById('totalDisplay');
    let rowIndex = 0;

    function rupiah(value) {
        return 'Rp ' + Number(value).toLocaleString('id-ID');
    }

    function escapeHtml(value) {
        return String(value).replace(/[&<>"']/g, character => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        })[character]);
    }

    function addItem() {
        const row = document.createElement('div');
        row.className = 'item-row';

        const options = products.map(product => `
            <option value="${product.id}"
                data-price="${product.price}"
                data-stock="${product.stock}">
                ${escapeHtml(product.name)} — ${rupiah(product.price)}
                (Stok: ${product.stock})
            </option>
        `).join('');

        row.innerHTML = `
            <div class="field">
                <label>Nama Barang</label>
                <select name="items[${rowIndex}][product_id]"
                    class="product-select" required>
                    <option value="">-- Pilih Barang --</option>
                    ${options}
                </select>
                <small class="stock-info">Pilih barang terlebih dahulu.</small>
            </div>

            <div class="field">
                <label>Jumlah Barang</label>
                <input type="number"
                    name="items[${rowIndex}][quantity]"
                    class="quantity-input"
                    min="1" value="1" required>
            </div>

            <div>
                <button type="button" class="remove-button">Hapus</button>
            </div>
        `;

        container.appendChild(row);
        rowIndex++;

        row.querySelector('.product-select').addEventListener('change', () => {
            updateStock(row);
            updateTotal();
        });

        row.querySelector('.quantity-input').addEventListener('input', updateTotal);

        row.querySelector('.remove-button').addEventListener('click', () => {
            if (container.querySelectorAll('.item-row').length === 1) {
                alert('Minimal harus ada satu barang.');
                return;
            }

            row.remove();
            updateTotal();
        });

        updateStock(row);
        updateTotal();
    }

    function updateStock(row) {
        const select = row.querySelector('.product-select');
        const option = select.options[select.selectedIndex];
        const quantity = row.querySelector('.quantity-input');
        const info = row.querySelector('.stock-info');

        if (select.value) {
            const stock = Number(option.dataset.stock);
            quantity.max = stock;
            info.textContent = 'Stok tersedia: ' + stock + ' barang.';
        } else {
            quantity.removeAttribute('max');
            info.textContent = 'Pilih barang terlebih dahulu.';
        }
    }

    function updateTotal() {
        let total = 0;
        const selectedIds = [];

        container.querySelectorAll('.item-row').forEach(row => {
            const select = row.querySelector('.product-select');
            const option = select.options[select.selectedIndex];
            const quantity = Number(
                row.querySelector('.quantity-input').value
            ) || 0;

            if (select.value) {
                total += Number(option.dataset.price) * quantity;
                selectedIds.push(select.value);
            }
        });

        totalDisplay.textContent = rupiah(total);

        container.querySelectorAll('.product-select').forEach(select => {
            const currentId = select.value;

            Array.from(select.options).forEach(option => {
                if (!option.value) return;

                option.disabled =
                    option.value !== currentId &&
                    selectedIds.includes(option.value);
            });
        });
    }

    document.getElementById('addItem')
        .addEventListener('click', addItem);

    addItem();
</script>

</body>
</html>
<?php /**PATH C:\xamppp\htdocs\uts-inventory-sales\resources\views/sales/create.blade.php ENDPATH**/ ?>