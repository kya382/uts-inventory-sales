
<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\PurchaseController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\SaleController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\UserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// Halaman awal
Route::get('/', function () {
    return redirect()->route('login');
});

// Login
Route::get('/login', function () {
    return view('login');
})->name('login');

Route::post('/login', [AuthController::class, 'login'])
    ->name('login.process');

// Semua halaman yang membutuhkan login
Route::middleware('auth')->group(function () {

    // Dashboard - Admin dan Staff
Route::get('/dashboard', function () {
    $totalBarang = \App\Models\Product::count();
    $totalStok = \App\Models\Product::sum('stock');

    $stokMenipis = \App\Models\Product::whereColumn(
        'stock',
        '<=',
        'minimum_stock'
    )->count();

    $totalSupplier = \App\Models\Supplier::count();

    // Grafik penjualan 7 hari terakhir
    $mulai = \Carbon\Carbon::today()->subDays(6);
    $sampai = \Carbon\Carbon::today()->endOfDay();

    $dataPenjualan = \App\Models\Sale::whereBetween(
        'sold_at',
        [$mulai, $sampai]
    )
        ->selectRaw('DATE(sold_at) as tanggal, SUM(total_amount) as total')
        ->groupByRaw('DATE(sold_at)')
        ->pluck('total', 'tanggal');

    $labelGrafik = [];
    $nilaiGrafik = [];

    for ($i = 0; $i < 7; $i++) {
        $tanggal = $mulai->copy()->addDays($i);

        $labelGrafik[] = $tanggal->format('d/m');
        $nilaiGrafik[] = (float) (
            $dataPenjualan[$tanggal->toDateString()] ?? 0
        );
    }

    return view('dashboard', compact(
        'totalBarang',
        'totalStok',
        'stokMenipis',
        'totalSupplier',
        'labelGrafik',
        'nilaiGrafik'
    ));
    })->name('dashboard');
    
    // Logout - Admin dan Staff
    Route::post('/logout', function (Request $request) {
        auth()->logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/login');
    })->name('logout');

    // Barang - Admin dan Staff boleh melihat
    Route::get('/products', [ProductController::class, 'index'])
        ->name('products.index');

    // Barang - hanya Admin boleh menambah, mengedit, menghapus
    Route::middleware('admin')->group(function () {
        Route::post('/products', [ProductController::class, 'store'])
            ->name('products.store');

        Route::get('/products/{product}/edit', [ProductController::class, 'edit'])
            ->name('products.edit');

        Route::put('/products/{product}', [ProductController::class, 'update'])
            ->name('products.update');

        Route::delete('/products/{product}', [ProductController::class, 'destroy'])
            ->name('products.destroy');
    });

    // Pembelian - Admin dan Staff boleh melihat dan membuat
    Route::resource('purchases', PurchaseController::class)
        ->only(['index', 'create', 'store', 'show']);

    // Pembelian - hanya Admin boleh mengedit dan menghapus
    Route::middleware('admin')->group(function () {
        Route::resource('purchases', PurchaseController::class)
            ->only(['edit', 'update', 'destroy']);
    });

    // Penjualan - Admin dan Staff boleh melihat dan membuat
    Route::resource('sales', SaleController::class)
        ->only(['index', 'create', 'store', 'show']);

    // Laporan Penjualan - Admin dan Staff
    Route::get('/reports/sales', [ReportController::class, 'index'])
        ->name('reports.sales');

    // Khusus Admin
    Route::middleware('admin')->group(function () {

        // Kategori
        Route::get('/categories', [CategoryController::class, 'index'])
            ->name('categories.index');

        Route::post('/categories', [CategoryController::class, 'store'])
            ->name('categories.store');

        // Supplier
        Route::resource('suppliers', SupplierController::class);

        // Data Pengguna
        Route::resource('users', UserController::class)
            ->only([
                'index',
                'create',
                'store',
                'edit',
                'update',
                'destroy'
            ]);
    });
});
