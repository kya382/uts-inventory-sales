<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Login Admin &amp; Staff</title>
    <style>
        * {
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #f4f6f9;
        }

        .login-box {
            width: 360px;
            max-width: 90%;
            padding: 32px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 5px 20px #00000012;
        }

        h2 {
            margin-bottom: 8px;
            text-align: center;
            color: #222;
        }

        .subtitle {
            text-align: center;
            color: #777;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin: 15px 0 7px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        button {
            width: 100%;
            margin-top: 22px;
            padding: 12px;
            border: none;
            border-radius: 6px;
            background: #e63946;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #c92f3b;
        }

        .error {
            color: #c62828;
            font-size: 14px;
            margin-top: 12px;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <h2>Login Admin &amp; Staff</h2>
        <p class="subtitle">Silakan masuk ke akun Anda</p>

        <form method="POST" action="{{ route('login') }}">
            @csrf

            <label for="username">Username</label>
            <input type="text" id="username" name="username"
                   placeholder="Masukkan username" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password"
                   placeholder="Masukkan password" required>

            @if ($errors->any())
                <p class="error">{{ $errors->first() }}</p>
            @endif

            <button type="submit">Masuk</button>
        </form>
    </div>
</body>
</html>