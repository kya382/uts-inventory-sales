```php
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Barang</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 30px;
        }

        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 8px #ddd;
        }

        h2 {
            color: #333;
            margin-top: 0;
        }

        label {
            display: block;
            margin-top: 15px;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            box-sizing: border-box;
        }

        button, .back {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 16px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }

        button {
            background: #991b1b;
            color: white;
        }

        .back {
            background: #ddd;
            color: #222;
        }

        .error {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Barang</h2>

        @if ($errors->any())
            <div class="error">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ url('/products/' . $product->id) }}" method="POST">
            @csrf
            @method('PUT')

            <label>Kode Barang</label>
            <input type="text" name="sku"
                   value="{{ old('sku', $product->sku) }}" required>

            <label>Nama Barang</label>
            <input type="text" name="name"
                   value="{{ old('name', $product->name) }}" required>

            <label>Kategori</label>
            <select name="category_id">
                <option value="">Pilih kategori</option>
                @foreach ($categories as $category)
                    <option value="{{ $category->id }}"
                        {{ old('category_id', $product->category_id) == $category->id ? 'selected' : '' }}>
                        {{ $category->name }}
                    </option>
                @endforeach
            </select>

            <label>Harga</label>
            <input type="number" name="price" min="0" step="0.01"
                   value="{{ old('price', $product->price) }}" required>

            <label>Stok</label>
            <input type="number" name="stock" min="0"
                   value="{{ old('stock', $product->stock) }}" required>

            <label>Batas Stok Minimum</label>
            <input type="number" name="minimum_stock" min="0"
                   value="{{ old('minimum_stock', $product->minimum_stock) }}" required>

            <button type="submit">Simpan Perubahan</button>
            <a href="{{ url('/products') }}" class="back">Kembali</a>
        </form>
    </div>
</body>
</html>
```