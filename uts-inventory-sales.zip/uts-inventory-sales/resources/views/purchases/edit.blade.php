
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pembelian</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f6fa;
            margin: 0;
            padding: 30px;
            color: #333;
        }

        .container {
            max-width: 650px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 8px #ddd;
        }

        h2 {
            margin-top: 0;
        }

        label {
            display: block;
            margin-top: 15px;
            margin-bottom: 7px;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            box-sizing: border-box;
            padding: 11px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .btn {
            display: inline-block;
            padding: 11px 16px;
            border: none;
            border-radius: 5px;
            color: white;
            text-decoration: none;
            cursor: pointer;
            margin-top: 20px;
            font-size: 14px;
        }

        .save {
            background: #dc2626;
        }

        .back {
            background: #6b7280;
        }

        .error {
            background: #fee2e2;
            color: #991b1b;
            padding: 12px;
            border-radius: 5px;
        }
    </style>
</head>

<body>
<div class="container">
    <h2>Edit Transaksi Pembelian</h2>
    <p>Ubah informasi pembelian barang di bawah ini.</p>

    @if ($errors->any())
        <div class="error">
            @foreach ($errors->all() as $error)
                <div>{{ $error }}</div>
            @endforeach
        </div>
    @endif

    <form action="{{ route('purchases.update', $purchase->id) }}"
          method="POST">
        @csrf
        @method('PUT')

        <label>Nomor Pembelian</label>
        <input type="text"
               value="{{ $purchase->purchase_number }}"
               disabled>

        <label>Supplier</label>
        <select name="supplier_id" required>
            @foreach ($suppliers as $supplier)
                <option value="{{ $supplier->id }}"
                    {{ old('supplier_id', $purchase->supplier_id) == $supplier->id ? 'selected' : '' }}>
                    {{ $supplier->name }}
                </option>
            @endforeach
        </select>

        <label>Tanggal Pembelian</label>
        <input type="date"
               name="purchase_date"
               value="{{ old('purchase_date', $purchase->purchase_date->format('Y-m-d')) }}"
               required>

        <label>Nama Barang</label>
        <select name="product_id" required>
            @foreach ($products as $product)
                <option value="{{ $product->id }}"
                    {{ old('product_id', $detail->product_id) == $product->id ? 'selected' : '' }}>
                    {{ $product->name }}
                </option>
            @endforeach
        </select>

        <label>Jumlah Barang</label>
        <input type="number"
               name="quantity"
               min="1"
               value="{{ old('quantity', $detail->quantity) }}"
               required>

        <label>Harga Beli per Barang (Rp)</label>
        <input type="number"
               name="price"
               min="1"
               step="1"
               value="{{ old('price', (int) $detail->price) }}"
               required>

        <button type="submit" class="btn save">
            Simpan Perubahan
        </button>

        <a href="{{ route('purchases.index') }}" class="btn back">
            Kembali
        </a>
    </form>
</div>
</body>
</html>
