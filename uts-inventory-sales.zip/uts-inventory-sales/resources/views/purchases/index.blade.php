<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi Pembelian - Berkah Elektronik</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f6fa;
            margin: 0;
            padding: 30px;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 8px #ddd;
            overflow-x: auto;
        }

        h2 {
            margin-top: 0;
        }

        .btn {
            display: inline-block;
            padding: 10px 15px;
            background: #dc2626;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .btn:hover {
            background: #b91c1c;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            text-align: left;
            white-space: nowrap;
        }

        th {
            background: #dc2626;
            color: white;
        }

        .detail-btn {
            display: inline-block;
            background: #dc2626;
            color: white;
            padding: 8px 12px;
            text-decoration: none;
            border-radius: 4px;
        }

        .detail-btn:hover {
            background: #b91c1c;
        }

        .empty {
            text-align: center;
            color: #777;
            padding: 25px;
        }

        .success {
            background: #dcfce7;
            color: #166534;
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 15px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Transaksi Pembelian</h2>
        <p>Kelola dan lihat data pembelian barang dari supplier.</p>

        <a href="{{ url('/dashboard') }}"
           class="btn"
           style="background:#555;">
            ← Kembali ke Dashboard
        </a>

        <a href="{{ route('purchases.create') }}" class="btn">
            + Tambah Pembelian
        </a>

        @if (session('success'))
            <div class="success">
                {{ session('success') }}
            </div>
        @endif

        @if ($errors->any())
            <div class="success" style="background:#fee2e2;color:#991b1b;">
                @foreach ($errors->all() as $error)
                    <div>{{ $error }}</div>
                @endforeach
            </div>
        @endif

        <table>
            <thead>
                <tr>
                    <th>No.</th>
                    <th>No. Pembelian</th>
                    <th>Supplier</th>
                    <th>Tanggal</th>
                    <th>Total Pembelian</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
                @forelse ($purchases as $purchase)
                    <tr>
                        <td>{{ $loop->iteration }}</td>

                        <td>{{ $purchase->purchase_number }}</td>

                        <td>{{ $purchase->supplier->name ?? '-' }}</td>

                        <td>
                            {{ $purchase->purchase_date->format('d-m-Y') }}
                        </td>

                        <td>
                            Rp {{ number_format((float) $purchase->total_amount, 0, ',', '.') }}
                        </td>

                        <td>{{ ucfirst($purchase->status) }}</td>

                        <td>
                            <a href="{{ route('purchases.show', $purchase->id) }}"
                               class="detail-btn">
                                Detail
                            </a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" class="empty">
                            Belum ada transaksi pembelian.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</body>
</html>