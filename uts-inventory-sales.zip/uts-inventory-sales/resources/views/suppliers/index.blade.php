<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Supplier | BERKAH ELEKTRONIK</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 30px;
            background: #f5f6fa;
            color: #292929;
        }

        .container {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 12px #0000000d;
            overflow-x: auto;
        }

        h2 {
            color: #991b1b;
            margin-top: 0;
            margin-bottom: 20px;
        }

        .btn {
            display: inline-block;
            padding: 10px 15px;
            background: #dc2626;
            color: white;
            text-decoration: none;
            border: none;
            border-radius: 5px;
            margin-bottom: 15px;
            cursor: pointer;
            font-size: 14px;
        }

        .btn:hover {
            background: #991b1b;
        }

        .btn-kembali {
            background: #64748b;
            margin-right: 5px;
        }

        .btn-kembali:hover {
            background: #475569;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            min-width: 700px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background: #991b1b;
            color: white;
        }

        tbody tr:hover {
            background: #fff7f7;
        }

        .edit {
            display: inline-block;
            background: #991b1b;
            color: white;
            padding: 7px 10px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 13px;
        }

        .edit:hover {
            background: #7f1d1d;
        }

        .hapus {
            background: #dc2626;
            color: white;
            padding: 7px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
        }

        .hapus:hover {
            background: #991b1b;
        }

        .success {
            background: #dcfce7;
            color: #166534;
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 5px;
        }

        .error {
            background: #fee2e2;
            color: #991b1b;
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 5px;
        }

        .pagination {
            margin-top: 20px;
        }

        @media (max-width: 600px) {
            body {
                padding: 12px;
            }

            .container {
                padding: 16px;
            }
        }
    </style>
</head>

<body>
<div class="container">

    <h2>🚚 Data Supplier</h2>

    <a href="{{ route('dashboard') }}" class="btn btn-kembali">
        ← Kembali ke Dashboard
    </a>

    <a href="{{ route('suppliers.create') }}" class="btn">
        + Tambah Supplier
    </a>

    @if (session('success'))
        <div class="success">
            {{ session('success') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="error">
            @foreach ($errors->all() as $error)
                <div>{{ $error }}</div>
            @endforeach
        </div>
    @endif

    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama Supplier</th>
                <th>Telepon</th>
                <th>Email</th>
                <th>Alamat</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
            @forelse ($suppliers as $supplier)
                <tr>
                    <td>{{ $suppliers->firstItem() + $loop->index }}</td>
                    <td>{{ $supplier->name }}</td>
                    <td>{{ $supplier->phone ?? '-' }}</td>
                    <td>{{ $supplier->email ?? '-' }}</td>
                    <td>{{ $supplier->address ?? '-' }}</td>
                    <td>
                        <a href="{{ route('suppliers.edit', $supplier->id) }}"
                           class="edit">Edit</a>

                        <form
                            action="{{ route('suppliers.destroy', $supplier->id) }}"
                            method="POST"
                            style="display:inline"
                            onsubmit="return confirm('Yakin ingin menghapus supplier ini?')">

                            @csrf
                            @method('DELETE')

                            <button type="submit" class="hapus">
                                Hapus
                            </button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="6" style="text-align:center;">
                        Belum ada data supplier.
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>

    <div class="pagination">
        {{ $suppliers->links() }}
    </div>

</div>
</body>
</html>