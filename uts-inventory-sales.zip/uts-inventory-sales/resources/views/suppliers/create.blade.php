
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Supplier</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            background: #f5f5f5;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 8px;
        }
        h2 {
            color: #333;
        }
        label {
            display: block;
            margin-top: 15px;
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button, .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }
        button {
            background: #dc2626;
            color: white;
        }
        .btn {
            background: #ddd;
            color: #333;
        }
        .error {
            color: #b91c1c;
            margin-top: 5px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Tambah Supplier</h2>

    @if ($errors->any())
        <div class="error">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('suppliers.store') }}" method="POST">
        @csrf

        <label>Nama Supplier *</label>
        <input type="text" name="name" value="{{ old('name') }}" required>

        <label>Nomor Telepon</label>
        <input type="text" name="phone" value="{{ old('phone') }}">

        <label>Email</label>
        <input type="email" name="email" value="{{ old('email') }}">

        <label>Alamat</label>
        <textarea name="address" rows="3">{{ old('address') }}</textarea>

        <button type="submit">Simpan Supplier</button>
        <a href="{{ route('suppliers.index') }}" class="btn">Kembali</a>
    </form>
</div>
</body>
</html>
