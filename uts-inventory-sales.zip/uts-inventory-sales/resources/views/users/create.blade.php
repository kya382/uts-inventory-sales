
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pengguna - Login Admin &amp; Staff</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 25px;
            color: #333;
        }

        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 8px #ddd;
        }

        h2 {
            color: #c62828;
            margin-top: 0;
        }

        label {
            display: block;
            margin: 15px 0 7px;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 11px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }

        input:focus, select:focus {
            outline: none;
            border-color: #c62828;
        }

        .btn {
            display: inline-block;
            padding: 11px 16px;
            margin-top: 20px;
            background: #c62828;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
        }

        .btn:hover {
            background: #a61f1f;
        }

        .btn-back {
            background: #555;
            margin-left: 5px;
        }

        .btn-back:hover {
            background: #333;
        }

        .error {
            color: #c62828;
            font-size: 13px;
            margin-top: 5px;
        }

        .alert {
            background: #fff0f0;
            border: 1px solid #f3b5b5;
            color: #a61f1f;
            padding: 12px;
            border-radius: 5px;
        }
    </style>
</head>

<body>
<div class="container">
    <h2>Tambah Pengguna</h2>
    <p>Masukkan data akun Admin atau Staff yang baru.</p>

    @if ($errors->any())
        <div class="alert">
            <strong>Periksa kembali data berikut:</strong>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('users.store') }}" method="POST">
        @csrf

        <label for="name">Nama Lengkap</label>
        <input
            type="text"
            id="name"
            name="name"
            value="{{ old('name') }}"
            required
        >

        <label for="username">Username</label>
        <input
            type="text"
            id="username"
            name="username"
            value="{{ old('username') }}"
            required
        >

        <label for="email">Email</label>
        <input
            type="email"
            id="email"
            name="email"
            value="{{ old('email') }}"
            required
        >

        <label for="password">Password</label>
        <input
            type="password"
            id="password"
            name="password"
            minlength="8"
            required
        >
        <small>Password minimal 8 karakter.</small>

        <label for="role">Jabatan</label>
        <select id="role" name="role" required>
            <option value="">-- Pilih Jabatan --</option>
            <option value="admin" {{ old('role') == 'admin' ? 'selected' : '' }}>Admin</option>
            <option value="staff" {{ old('role') == 'staff' ? 'selected' : '' }}>Staff</option>
        </select>

        <button type="submit" class="btn">Simpan Pengguna</button>
        <a href="{{ route('users.index') }}" class="btn btn-back">Kembali</a>
    </form>
</div>
</body>
</html>
