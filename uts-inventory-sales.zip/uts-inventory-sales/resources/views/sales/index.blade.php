
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penjualan - Login Admin &amp; Staff</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 25px;
            color: #333;
        }

        .container {
            max-width: 1100px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px #ddd;
        }

        h2 {
            color: #c62828;
            margin-top: 0;
        }

        .tambah {
            display: inline-block;
            background: #c62828;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .pesan {
            background: #d4edda;
            color: #155724;
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #c62828;
            color: white;
        }

        .detail {
            display: inline-block;
            background: #1976d2;
            color: white;
            padding: 7px 10px;
            border-radius: 4px;
            text-decoration: none;
        }

        .kosong {
            text-align: center;
            color: #777;
            padding: 25px;
        }

        


.pagination {
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid #ddd;
}

.pagination nav {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
}

.pagination nav > div:first-child {
    font-size: 16px;
}

.pagination nav > div:last-child {
    display: flex;
    align-items: center;
    gap: 8px;
}

.pagination nav a,
.pagination nav span {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    min-width: 40px;
    min-height: 40px;
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 7px;
    background: white;
    color: #991b1b;
    text-decoration: none;
    font-size: 16px;
}

.pagination nav span[aria-current="page"] span {
    background: #991b1b;
    color: white;
}

.pagination svg {
    width: 16px !important;
    height: 16px !important;
}



    </style>
</head>
<body>

<div class="container">
    <h2>Data Penjualan</h2>
    <p>Daftar transaksi penjualan barang.</p>

    
<a href="{{ route('sales.create') }}" class="tambah">
    + Tambah Penjualan
</a>

<a href="{{ url('/dashboard') }}"
   style="display:inline-block;background:#555;color:white;padding:10px 15px;text-decoration:none;border-radius:5px;margin-bottom:20px;margin-left:5px;">
    Kembali ke Halaman Utama
</a>


    @if (session('success'))
        <div class="pesan">
            {{ session('success') }}
        </div>
    @endif

    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>No.</th>
                    <th>No. Transaksi</th>
                    <th>Tanggal</th>
                    <th>Kasir</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
                @forelse ($sales as $sale)
                    <tr>
                        <td>{{ $sales->firstItem() + $loop->index }}</td>
                        <td>{{ $sale->sale_number }}</td>
                        <td>{{ $sale->sold_at->format('d-m-Y H:i') }}</td>
                        <td>{{ $sale->user->name ?? '-' }}</td>
                        <td>
                            Rp {{ number_format($sale->total_amount, 0, ',', '.') }}
                        </td>
                        <td>{{ ucfirst($sale->status) }}</td>
                        <td>
                            <a href="{{ route('sales.show', $sale->id) }}"
                               class="detail">Detail</a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" class="kosong">
                            Belum ada transaksi penjualan.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="pagination">
        {{ $sales->links() }}
    </div>
</div>

</body>
</html>
