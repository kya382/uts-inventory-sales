<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk Penjualan - Berkah Elektronik</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 25px;
            color: #333;
        }

        .container {
            max-width: 700px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px #ddd;
        }

        .judul {
            text-align: center;
            border-bottom: 2px dashed #999;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }

        .judul h2 {
            color: #c62828;
            margin: 0 0 8px;
        }

        .judul p {
            margin: 5px 0;
        }

        .info {
            line-height: 1.9;
            margin-bottom: 20px;
            overflow-wrap: anywhere;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th, td {
            padding: 10px 6px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #c62828;
            color: white;
        }

        .angka {
            text-align: right;
            white-space: nowrap;
        }

        .total {
            text-align: right;
            font-size: 20px;
            font-weight: bold;
            margin-top: 20px;
            padding-top: 15px;
            border-top: 2px dashed #999;
        }

        .terima-kasih {
            text-align: center;
            margin-top: 30px;
            border-top: 1px dashed #999;
            padding-top: 15px;
        }

        .tombol {
            display: inline-block;
            padding: 11px 16px;
            border-radius: 5px;
            text-decoration: none;
            border: none;
            cursor: pointer;
            font-size: 15px;
            margin-top: 20px;
            margin-right: 5px;
        }

        .cetak {
            background: #c62828;
            color: white;
        }

        .kembali {
            background: #777;
            color: white;
        }

        @media print {
            @page {
                margin: 10mm;
            }

            body {
                background: white;
                padding: 0;
                color: black;
            }

            .container {
                max-width: none;
                padding: 0;
                margin: 0;
                box-shadow: none;
                border-radius: 0;
            }

            .aksi {
                display: none !important;
            }

            th {
                background: #eee !important;
                color: black !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }

            tr {
                page-break-inside: avoid;
            }
        }
    </style>
</head>
<body>

<div class="container">

    <div class="judul">
        <h2>STRUK PENJUALAN</h2>
        <p><strong>BERKAH ELEKTRONIK</strong></p>
        <p>Bukti Transaksi Penjualan Barang</p>
    </div>

    <div class="info">
        <strong>No. Transaksi:</strong>
        {{ $sale->sale_number }}<br>

        <strong>Tanggal:</strong>
        {{ $sale->sold_at->format('d-m-Y H:i') }}<br>

        <strong>Kasir:</strong>
        {{ $sale->user->name ?? '-' }}<br>

        <strong>Status:</strong>
        {{ ucfirst($sale->status) }}
    </div>

    <h3>Rincian Barang</h3>

    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama Barang</th>
                <th class="angka">Harga</th>
                <th class="angka">Jumlah</th>
                <th class="angka">Subtotal</th>
            </tr>
        </thead>

        <tbody>
            @foreach ($sale->items as $item)
                <tr>
                    <td>{{ $loop->iteration }}</td>

                    <td>
                        {{ $item->product->name ?? 'Barang dihapus' }}
                    </td>

                    <td class="angka">
                        Rp {{ number_format($item->unit_price, 0, ',', '.') }}
                    </td>

                    <td class="angka">
                        {{ $item->quantity }}
                    </td>

                    <td class="angka">
                        Rp {{ number_format($item->subtotal, 0, ',', '.') }}
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <div class="total">
        Total Bayar:
        Rp {{ number_format($sale->total_amount, 0, ',', '.') }}
    </div>

    <div class="terima-kasih">
        <p><strong>Terima kasih telah berbelanja!</strong></p>
        <p>Harap simpan struk ini sebagai bukti transaksi.</p>
    </div>

    <div class="aksi">
        <button type="button" class="tombol cetak" onclick="window.print()">
            Cetak Struk
        </button>

        <a href="{{ route('sales.index') }}" class="tombol kembali">
            Kembali ke Penjualan
        </a>
    </div>

</div>

</body>