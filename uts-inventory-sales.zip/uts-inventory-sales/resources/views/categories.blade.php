
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Kategori | BERKAH ELEKTRONIK</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f5f6fa;
            color: #292929;
        }

        .sidebar {
            width: 250px;
            height: 100vh;
            background: #991b1b;
            color: white;
            position: fixed;
            top: 0;
            left: 0;
            padding: 25px 16px;
            display: flex;
            flex-direction: column;
        }

        .brand {
            font-size: 19px;
            font-weight: bold;
            line-height: 1.5;
            padding: 0 10px 30px;
            border-bottom: 1px solid #c65a5a;
        }

        .brand small {
            display: block;
            font-size: 12px;
            font-weight: normal;
            color: #fee2e2;
        }

        .menu-title {
            font-size: 11px;
            color: #fecaca;
            margin: 25px 10px 10px;
            letter-spacing: 1px;
        }

        .menu {
            display: block;
            color: white;
            text-decoration: none;
            padding: 13px 12px;
            margin: 4px 0;
            border-radius: 8px;
            font-size: 14px;
        }

        .menu:hover,
        .menu.active {
            background: #dc2626;
        }

        .logout {
            margin-top: auto;
        }

        .logout button {
            width: 100%;
            padding: 12px;
            border: 1px solid #fecaca;
            border-radius: 8px;
            background: transparent;
            color: white;
            cursor: pointer;
            font-size: 14px;
        }

        .main {
            margin-left: 250px;
            padding: 30px;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            margin-bottom: 25px;
        }

        .topbar h1 {
            font-size: 27px;
            margin-bottom: 8px;
        }

        .subtitle {
            color: #777;
            font-size: 14px;
        }

        .admin {
            background: white;
            padding: 12px 18px;
            border: 1px solid #eee;
            border-radius: 10px;
        }

        .container {
            background: white;
            padding: 25px;
            border-radius: 12px;
            border: 1px solid #eee;
            box-shadow: 0 3px 12px #00000008;
        }

        .heading {
            margin-bottom: 20px;
        }

        .heading h2 {
            font-size: 20px;
            margin-bottom: 8px;
        }

        .heading p {
            color: #777;
            font-size: 14px;
        }

        .button {
            display: inline-block;
            padding: 11px 16px;
            border: none;
            border-radius: 7px;
            background: #dc2626;
            color: white;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
        }

        .button:hover {
            background: #b91c1c;
        }

        .back {
            background: #991b1b;
            margin-bottom: 25px;
        }

        .form-section {
            background: #fffafa;
            border: 1px solid #fee2e2;
            border-radius: 10px;
            padding: 22px;
            margin-bottom: 30px;
        }

        .form-section h3,
        .table-section h3 {
            font-size: 18px;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-size: 14px;
            font-weight: bold;
        }

        input,
        textarea {
            display: block;
            width: 100%;
            padding: 12px;
            margin-bottom: 18px;
            border: 1px solid #ddd;
            border-radius: 7px;
            font-family: Arial, sans-serif;
            font-size: 14px;
        }

        input:focus,
        textarea:focus {
            outline: none;
            border-color: #dc2626;
            box-shadow: 0 0 0 3px #fee2e2;
        }

        textarea {
            min-height: 95px;
            resize: vertical;
        }

        .message {
            background: #dcfce7;
            color: #166534;
            padding: 13px;
            margin-bottom: 20px;
            border-radius: 7px;
        }

        .error {
            background: #fef2f2;
            color: #b91c1c;
            padding: 13px;
            margin-bottom: 20px;
            border-radius: 7px;
        }

        .error ul {
            padding-left: 20px;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }

        th, td {
            padding: 15px 13px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }

        th {
            background: #991b1b;
            color: white;
        }

        tbody tr:hover {
            background: #fff7f7;
        }

        .empty {
            text-align: center;
            padding: 25px;
            color: #888;
        }

        .footer {
            text-align: center;
            color: #999;
            font-size: 12px;
            margin-top: 25px;
        }

        @media (max-width: 800px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .logout {
                margin-top: 15px;
            }

            .main {
                margin-left: 0;
                padding: 18px;
            }

            .topbar {
                align-items: flex-start;
                flex-direction: column;
            }
        }
    </style>
</head>

<body>

<aside class="sidebar">
    <div class="brand">
        📦 BERKAH ELEKTRONIK
        <small>Management System</small>
    </div>

    <div class="menu-title">MENU UTAMA</div>

    <a href="{{ url('/dashboard') }}" class="menu">
        🏠 &nbsp; Dashboard
    </a>

    <a href="{{ url('/products') }}" class="menu">
        📦 &nbsp; Kelola Barang
    </a>

    <a href="{{ url('/categories') }}" class="menu active">
        🗂️ &nbsp; Kelola Kategori
    </a>

    <a href="{{ route('suppliers.index') }}" class="menu">
        🚚 &nbsp; Kelola Supplier
    </a>

    <div class="menu-title">TRANSAKSI</div>

    <a href="#" class="menu"
       onclick="alert('Fitur pembelian akan dibuat selanjutnya.'); return false;">
        🛒 &nbsp; Pembelian
    </a>

    <a href="#" class="menu"
       onclick="alert('Fitur penjualan akan dibuat selanjutnya.'); return false;">
        💳 &nbsp; Penjualan
    </a>

    <div class="logout">
        <form action="{{ url('/logout') }}" method="POST">
            @csrf
            <button type="submit">↪ &nbsp; Keluar / Logout</button>
        </form>
    </div>
</aside>

<main class="main">

    <header class="topbar">
        <div>
            <h1>Kelola Kategori</h1>
            <p class="subtitle">
                Atur kategori agar data barang lebih rapi dan mudah dicari.
            </p>
        </div>

        <div class="admin">👤 &nbsp; Admin</div>
    </header>

    <div class="container">

        <div class="heading">
            <h2>Data Kategori</h2>
            <p>Tambah dan lihat kategori barang yang tersimpan.</p>
        </div>

        <a href="{{ url('/dashboard') }}" class="button back">
            ← Kembali ke Dashboard
        </a>

        @if (session('success'))
            <div class="message">
                ✓ {{ session('success') }}
            </div>
        @endif

        @if ($errors->any())
            <div class="error">
                <strong>Data belum bisa disimpan:</strong>
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <section class="form-section">
            <h3>＋ Tambah Kategori</h3>

            <form action="{{ url('/categories') }}" method="POST">
                @csrf

                <label for="name">Nama Kategori</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    value="{{ old('name') }}"
                    placeholder="Contoh: Elektronik"
                    required
                >

                <label for="description">Keterangan</label>
                <textarea
                    id="description"
                    name="description"
                    placeholder="Keterangan kategori (opsional)"
                >{{ old('description') }}</textarea>

                <button type="submit" class="button">
                    Simpan Kategori
                </button>
            </form>
        </section>

        <section class="table-section">
            <h3>Daftar Kategori</h3>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th style="width:70px;">No.</th>
                            <th>Nama Kategori</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>

                    <tbody>
                        @forelse ($categories as $category)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $category->name }}</td>
                                <td>{{ $category->description ?? '-' }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="3" class="empty">
                                    Belum ada data kategori.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </section>

    </div>

    <div class="footer">
        BERKAH ELEKTRONIK Management System
    </div>

</main>

</body>
</html>
