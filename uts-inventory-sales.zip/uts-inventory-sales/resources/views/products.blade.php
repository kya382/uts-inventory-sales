
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Barang - Login Admin &amp; Staff</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 30px;
            color: #333;
        }

        .container {
            max-width: 1100px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 8px #ddd;
        }

        h1 { color: #991b1b; }

        input, select {
            width: 100%;
            padding: 10px;
            margin: 8px 0 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button, .button {
            display: inline-block;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            background: #991b1b;
            color: white;
            text-decoration: none;
            cursor: pointer;
        }

        .back { background: #64748b; }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th { background: #991b1b; color: white; }

        .message {
            background: #dcfce7;
            padding: 12px;
            margin: 15px 0;
            border-radius: 5px;
        }

        .error { color: #dc2626; }

        .table-wrap { overflow-x: auto; }

        .filter-form {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr auto auto;
            gap: 10px;
            align-items: center;
            margin-top: 20px;
        }

        .filter-form input,
        .filter-form select {
            margin: 0;
        }

        .pagination {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 20px;
        }

        .pagination-links {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }

        .pagination-links a,
        .pagination-links span {
            display: inline-block;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-decoration: none;
            color: #991b1b;
        }

        .pagination-links span {
            background: #991b1b;
            color: white;
        }

        @media (max-width: 750px) {
            body { padding: 12px; }
            .container { padding: 15px; }
            .filter-form { grid-template-columns: 1fr; }
        }
    </style>
</head>

<body>
<div class="container">
    <h1>Kelola Barang</h1>
    <a href="/dashboard" class="button back">Kembali</a>

    <form action="{{ url('/products') }}" method="GET" class="filter-form">
        <input
            type="text"
            name="search"
            value="{{ $search ?? '' }}"
            placeholder="Cari kode atau nama barang..."
        >

        <select name="category_id">
            <option value="">Semua kategori</option>
            @foreach ($categories as $category)
                <option value="{{ $category->id }}"
                    @selected(($categoryId ?? '') == $category->id)>
                    {{ $category->name }}
                </option>
            @endforeach
        </select>

        <select name="sort">
            <option value="latest" @selected(($sort ?? 'latest') === 'latest')>
                Terbaru
            </option>
            <option value="name" @selected(($sort ?? '') === 'name')>
                Nama A-Z
            </option>
            <option value="price_asc" @selected(($sort ?? '') === 'price_asc')>
                Harga terendah
            </option>
            <option value="price_desc" @selected(($sort ?? '') === 'price_desc')>
                Harga tertinggi
            </option>
        </select>

        <button type="submit">Terapkan</button>
        <a href="{{ url('/products') }}" class="button back">Reset</a>
    </form>

    @if (session('success'))
        <div class="message">{{ session('success') }}</div>
    @endif

    @if ($errors->any())
        <div class="error">
            @foreach ($errors->all() as $error)
                <p>{{ $error }}</p>
            @endforeach
        </div>
    @endif

    <h2>Tambah Barang</h2>

    <form action="{{ url('/products') }}" method="POST">
        @csrf

        <label>Kode Barang (SKU)</label>
        <input type="text" name="sku" value="{{ old('sku') }}"
               placeholder="Contoh: BRG001" required>

        <label>Nama Barang</label>
        <input type="text" name="name" value="{{ old('name') }}"
               placeholder="Masukkan nama barang" required>

        <label>Kategori</label>
        <select name="category_id">
            <option value="">Pilih kategori (opsional)</option>
            @foreach ($categories as $category)
                <option value="{{ $category->id }}"
                    @selected(old('category_id') == $category->id)>
                    {{ $category->name }}
                </option>
            @endforeach
        </select>

        <label>Harga</label>
        <input type="number" name="price" min="0" step="0.01"
               value="{{ old('price', 0) }}" required>

        <label>Stok</label>
        <input type="number" name="stock" min="0"
               value="{{ old('stock', 0) }}" required>

        <label>Stok Minimum</label>
        <input type="number" name="minimum_stock" min="0"
               value="{{ old('minimum_stock', 5) }}" required>

        <button type="submit">Simpan Barang</button>
    </form>

    <h2>Daftar Barang</h2>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Kode</th>
                    <th>Nama Barang</th>
                    <th>Kategori</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Stok Minimum</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
                @forelse ($products as $product)
                    <tr>
                        <td>{{ $products->firstItem() + $loop->index }}</td>
                        <td>{{ $product->sku }}</td>
                        <td>{{ $product->name }}</td>
                        <td>{{ $product->category->name ?? '-' }}</td>
                        <td>Rp {{ number_format($product->price, 0, ',', '.') }}</td>
                        <td>
                            {{ $product->stock }}

                            @if ($product->stock <= $product->minimum_stock)
                                <br>
                                <span style="color: #dc2626; font-weight: bold;">
                                    Stok Menipis!
                                </span>
                            @else
                                <br>
                                <span style="color: #16a34a; font-weight: bold;">
                                    Stok Aman
                                </span>
                            @endif
                        </td>
                        <td>{{ $product->minimum_stock }}</td>
                        <td>
                            <a href="{{ url('/products/' . $product->id . '/edit') }}"
                               class="button">Edit</a>

                            <form action="{{ url('/products/' . $product->id) }}"
                                  method="POST"
                                  style="display:inline;"
                                  onsubmit="return confirm('Yakin ingin menghapus barang ini?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" style="background:#dc2626;">
                                    Hapus
                                </button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="8" style="text-align:center">
                            Belum ada data barang.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="pagination">
        <div>
            Menampilkan {{ $products->firstItem() ?? 0 }}–{{ $products->lastItem() ?? 0 }}
            dari {{ $products->total() }} barang
        </div>

        <div class="pagination-links">
            @if ($products->onFirstPage())
                <a style="color:#999;">Sebelumnya</a>
            @else
                <a href="{{ $products->previousPageUrl() }}">Sebelumnya</a>
            @endif

            @foreach ($products->getUrlRange(1, $products->lastPage()) as $page => $url)
                @if ($page == $products->currentPage())
                    <span>{{ $page }}</span>
                @else
                    <a href="{{ $url }}">{{ $page }}</a>
                @endif
            @endforeach

            @if ($products->hasMorePages())
                <a href="{{ $products->nextPageUrl() }}">Berikutnya</a>
            @else
                <a style="color:#999;">Berikutnya</a>
            @endif
        </div>
    </div>
</div>

<script>
    const priceDisplay = document.getElementById('price_display');
    const priceValue = document.getElementById('price');

    priceDisplay.addEventListener('input', function () {
        let angka = this.value.replace(/\D/g, '');

        priceValue.value = angka;
        this.value = angka
            ? Number(angka).toLocaleString('id-ID')
            : '';
    });
</script>

</body>
</html>
