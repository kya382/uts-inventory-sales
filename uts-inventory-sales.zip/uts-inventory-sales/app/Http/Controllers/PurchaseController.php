<?php

namespace App\Http\Controllers;

use App\Models\Purchase;
use App\Models\PurchaseDetail;
use App\Models\Supplier;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class PurchaseController extends Controller
{
    public function index()
    {
        $purchases = Purchase::with('supplier')
            ->latest()
            ->get();

        return view('purchases.index', compact('purchases'));
    }

    public function create()
    {
        $suppliers = Supplier::orderBy('name')->get();
        $products = Product::orderBy('name')->get();

        return view(
            'purchases.create',
            compact('suppliers', 'products')
        );
    }

    public function store(Request $request)
    {
        $request->validate([
            'supplier_id' => 'required|exists:suppliers,id',
            'purchase_date' => 'required|date',
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1',
            'price' => 'required|numeric|min:1',
        ]);

        DB::transaction(function () use ($request) {
            $quantity = (int) $request->quantity;
            $price = (float) $request->price;
            $total = $quantity * $price;

            $purchase = Purchase::create([
                'purchase_number' => 'PB-' . date('YmdHis')
                    . '-' . random_int(100, 999),
                'supplier_id' => $request->supplier_id,
                'purchase_date' => $request->purchase_date,
                'total_amount' => $total,
                'status' => 'completed',
            ]);

            PurchaseDetail::create([
                'purchase_id' => $purchase->id,
                'product_id' => $request->product_id,
                'quantity' => $quantity,
                'price' => $price,
                'subtotal' => $total,
            ]);

            Product::whereKey($request->product_id)
                ->increment('stock', $quantity);
        });

        return redirect()
            ->route('purchases.index')
            ->with('success', 'Transaksi pembelian berhasil disimpan!');
    }

    // Menampilkan detail transaksi pembelian.
    public function show(Purchase $purchase)
    {
        $purchase->load([
            'supplier',
            'details.product',
        ]);

        return view('purchases.show', compact('purchase'));
    }

    public function edit(Purchase $purchase)
    {
        $purchase->load('details');

        $detail = $purchase->details->first();

        if (!$detail) {
            return redirect()
                ->route('purchases.index')
                ->with('error', 'Detail pembelian tidak ditemukan.');
        }

        $suppliers = Supplier::orderBy('name')->get();
        $products = Product::orderBy('name')->get();

        return view(
            'purchases.edit',
            compact('purchase', 'detail', 'suppliers', 'products')
        );
    }

    public function update(Request $request, Purchase $purchase)
    {
        $request->validate([
            'supplier_id' => 'required|exists:suppliers,id',
            'purchase_date' => 'required|date',
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1',
            'price' => 'required|numeric|min:1',
        ]);

        DB::transaction(function () use ($request, $purchase) {
            $purchase = Purchase::whereKey($purchase->id)
                ->lockForUpdate()
                ->firstOrFail();

            $detail = $purchase->details()->first();

            if (!$detail) {
                throw ValidationException::withMessages([
                    'purchase' => 'Detail pembelian tidak ditemukan.',
                ]);
            }

            $oldProduct = Product::whereKey($detail->product_id)
                ->lockForUpdate()
                ->firstOrFail();

            if ($oldProduct->stock < $detail->quantity) {
                throw ValidationException::withMessages([
                    'quantity' => 'Stok barang sudah berkurang karena transaksi lain. Pembelian ini tidak bisa diedit dengan aman.',
                ]);
            }

            $newProduct = Product::whereKey($request->product_id)
                ->lockForUpdate()
                ->firstOrFail();

            // Batalkan pengaruh stok dari pembelian lama.
            $oldProduct->decrement('stock', $detail->quantity);

            $newQuantity = (int) $request->quantity;
            $newPrice = (float) $request->price;
            $subtotal = $newQuantity * $newPrice;

            // Terapkan stok dari pembelian yang diperbarui.
            $newProduct->increment('stock', $newQuantity);

            $purchase->update([
                'supplier_id' => $request->supplier_id,
                'purchase_date' => $request->purchase_date,
                'total_amount' => $subtotal,
            ]);

            $detail->update([
                'product_id' => $request->product_id,
                'quantity' => $newQuantity,
                'price' => $newPrice,
                'subtotal' => $subtotal,
            ]);
        });

        return redirect()
            ->route('purchases.index')
            ->with('success', 'Transaksi pembelian berhasil diperbarui!');
    }

    public function destroy(Purchase $purchase)
    {
        DB::transaction(function () use ($purchase) {
            $purchase = Purchase::whereKey($purchase->id)
                ->lockForUpdate()
                ->firstOrFail();

            $details = $purchase->details;

            foreach ($details as $detail) {
                $product = Product::whereKey($detail->product_id)
                    ->lockForUpdate()
                    ->firstOrFail();

                if ($product->stock < $detail->quantity) {
                    throw ValidationException::withMessages([
                        'purchase' => 'Pembelian tidak bisa dihapus karena stok barang sudah terpakai. Stok tidak diubah.',
                    ]);
                }
            }

            foreach ($details as $detail) {
                Product::whereKey($detail->product_id)
                    ->decrement('stock', $detail->quantity);
            }

            $purchase->delete();
        });

        return redirect()
            ->route('purchases.index')
            ->with('success', 'Transaksi pembelian berhasil dihapus!');
    }
}