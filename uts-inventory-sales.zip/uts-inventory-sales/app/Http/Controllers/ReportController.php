<?php

namespace App\Http\Controllers;

use App\Models\Sale;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function index(Request $request)
    {
        $tanggalAwal = $request->input('tanggal_awal');
        $tanggalAkhir = $request->input('tanggal_akhir');

        $query = Sale::query()
            ->where('status', 'completed');

        if ($tanggalAwal) {
            $query->whereDate('sold_at', '>=', $tanggalAwal);
        }

        if ($tanggalAkhir) {
            $query->whereDate('sold_at', '<=', $tanggalAkhir);
        }

        $totalTransaksi = (clone $query)->count();

        $totalOmzet = (clone $query)->sum('total_amount');

        $penjualan = (clone $query)
            ->with(['items.product'])
            ->orderByDesc('sold_at')
            ->paginate(10)
            ->withQueryString();

        $barangTerjual = DB::table('sale_items')
            ->join('sales', 'sale_items.sale_id', '=', 'sales.id')
            ->join('products', 'sale_items.product_id', '=', 'products.id')
            ->where('sales.status', 'completed')
            ->when($tanggalAwal, function ($q) use ($tanggalAwal) {
                $q->whereDate('sales.sold_at', '>=', $tanggalAwal);
            })
            ->when($tanggalAkhir, function ($q) use ($tanggalAkhir) {
                $q->whereDate('sales.sold_at', '<=', $tanggalAkhir);
            })
            ->select(
                'products.name as nama_barang',
                DB::raw('SUM(sale_items.quantity) as jumlah_terjual'),
                DB::raw('SUM(sale_items.subtotal) as total_penjualan')
            )
            ->groupBy('products.id', 'products.name')
            ->orderByDesc('jumlah_terjual')
            ->get();

        return view('reports.sales', compact(
            'tanggalAwal',
            'tanggalAkhir',
            'totalTransaksi',
            'totalOmzet',
            'penjualan',
            'barangTerjual'
        ));
    }
}
