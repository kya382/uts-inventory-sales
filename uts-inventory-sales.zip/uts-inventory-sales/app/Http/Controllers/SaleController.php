<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Sale;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class SaleController extends Controller
{
    public function index()
    {
        $sales = Sale::with(['user', 'items.product'])
            ->latest()
            ->paginate(10);

        return view('sales.index', compact('sales'));
    }

    public function create()
    {
        $products = Product::where('stock', '>', 0)
            ->orderBy('name')
            ->get();

        return view('sales.create', compact('products'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'sold_at' => ['required', 'date'],
            'items' => ['required', 'array', 'min:1'],
            'items.*.product_id' => [
                'required',
                'distinct',
                'exists:products,id',
            ],
            'items.*.quantity' => [
                'required',
                'integer',
                'min:1',
            ],
        ]);

        DB::transaction(function () use ($request) {
            $items = $request->input('items');
            $preparedItems = [];
            $total = 0;

            // Urutkan ID barang agar penguncian stok lebih teratur.
            $productIds = collect($items)
                ->pluck('product_id')
                ->map(fn ($id) => (int) $id)
                ->sort()
                ->values();

            $lockedProducts = [];

            foreach ($productIds as $productId) {
                $product = Product::whereKey($productId)
                    ->lockForUpdate()
                    ->firstOrFail();

                $lockedProducts[$productId] = $product;
            }

            // Periksa stok dan hitung total seluruh barang.
            foreach ($items as $index => $item) {
                $productId = (int) $item['product_id'];
                $quantity = (int) $item['quantity'];
                $product = $lockedProducts[$productId];

                if ($product->stock < $quantity) {
                    throw ValidationException::withMessages([
                        "items.$index.quantity" =>
                            'Stok ' . $product->name
                            . ' tidak mencukupi. Stok tersedia: '
                            . $product->stock,
                    ]);
                }

                $price = (float) $product->price;
                $subtotal = round($price * $quantity, 2);

                $preparedItems[] = [
                    'product' => $product,
                    'quantity' => $quantity,
                    'unit_price' => $price,
                    'subtotal' => $subtotal,
                ];

                $total += $subtotal;
            }

            // Buat satu transaksi untuk seluruh barang.
            $sale = Sale::create([
                'sale_number' => 'TRX-' . now()->format('YmdHis')
                    . '-' . strtoupper(Str::random(4)),
                'user_id' => auth()->id(),
                'total_amount' => round($total, 2),
                'status' => 'completed',
                'sold_at' => $request->sold_at,
            ]);

            // Simpan setiap barang dan kurangi stoknya.
            foreach ($preparedItems as $item) {
                $sale->items()->create([
                    'product_id' => $item['product']->id,
                    'quantity' => $item['quantity'],
                    'unit_price' => $item['unit_price'],
                    'subtotal' => $item['subtotal'],
                ]);

                $item['product']->decrement(
                    'stock',
                    $item['quantity']
                );
            }
        });

        return redirect()
            ->route('sales.index')
            ->with(
                'success',
                'Transaksi penjualan berhasil disimpan!'
            );
    }

    public function show(Sale $sale)
    {
        $sale->load(['user', 'items.product']);

        return view('sales.show', compact('sale'));
    }
}
